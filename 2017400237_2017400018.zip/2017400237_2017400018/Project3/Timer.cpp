#include "Timer.h"

Timer::Timer() : QObject()
{
    this->counter = 0;
    this->tmr = new QTimer(this);
    this->label = new QLabel("Time (secs): 0");
    this->tmr->start(1000);
    QObject::connect(this->tmr, SIGNAL(timeout()), this, SLOT(timerSlot()));
}

void Timer:: timerSlot(){
    this->counter += 1;
    this->label->setText("Time (secs): " + QString::number(counter));

    if(this->counter >= 180){
        this->tmr->stop();
        emit endOfTime();
        QMessageBox *mb = new QMessageBox();
        mb->setText("You Failed!");
        mb->setStandardButtons(QMessageBox::Cancel);
        mb->exec();
    }
}

void Timer:: newTimer(){
    this->counter = 0;
    this->tmr = new QTimer(this);
    this->label = new QLabel("Time (secs): 0");
    this->tmr->start(1000);
}
