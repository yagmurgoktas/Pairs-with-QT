#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include "Timer.h"
#include "Button.h"
#include "Layout.h"
#include "Score.h"

int main(int argc, char *argv[])
{

    QApplication app(argc, argv);
    QWidget *cw = new QWidget();
    QVBoxLayout *vb = new QVBoxLayout();
    QHBoxLayout *hb = new QHBoxLayout();
    QLabel *gamelabel = new QLabel();
    Timer *tmr = new Timer();
    Score *scr = new Score();
    Layout *grid = new Layout(tmr->tmr,scr,tmr);

    QPushButton *quit = new QPushButton("QUIT");
    QObject::connect(quit, SIGNAL(clicked()), &app, SLOT(quit()));

    QPushButton *newgame = new QPushButton("NEW GAME");
    QObject::connect(newgame, SIGNAL(clicked()), grid, SLOT(newGame()));

    QObject::connect(tmr, SIGNAL(endOfTime()), grid, SLOT(disableCarts()));

    QSpacerItem *spaceGrid = new QSpacerItem(0, 10, QSizePolicy::Expanding, QSizePolicy::Expanding);
    QSpacerItem *space = new QSpacerItem(10, 0, QSizePolicy::Expanding, QSizePolicy::Expanding);

    gamelabel->setText("Card Match Game");

    cw->setLayout(vb);
    hb->addWidget(tmr->label);
    hb->addWidget(scr->label);
    hb->addSpacerItem(space);
    hb->addWidget(newgame);
    hb->addWidget(quit);
    vb->addWidget(gamelabel);
    vb->addLayout(hb);
    vb->addSpacerItem(spaceGrid);
    vb->addLayout(grid);
    cw->show();

    return app.exec();
}

