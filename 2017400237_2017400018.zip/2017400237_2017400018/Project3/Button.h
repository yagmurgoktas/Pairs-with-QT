#ifndef BUTTON_H
#define BUTTON_H

#include <QWidget>
#include <QPushButton>

class Button : public QPushButton
{
    Q_OBJECT

public:
    Button(const QString& word, const QString& text, QWidget* parent = 0);
    QString word;
    bool empty;
};

#endif // BUTTON_H
