#include "Layout.h"

Layout::Layout(QTimer* timer , Score* scr , Timer* tmr) : QGridLayout()
{
    this->clickCount = 0;
    this->prevClicked = -1; //never clicked a button
    this->scr=scr;
    this->timer = timer;
    this->tmr=tmr;

    for(int row = 0; row < 5; row++){
        for(int col = 0; col < 6; col++){
            Button *b = new Button("", "?");
            this->addWidget(b, row, col, 1, 1);
            QObject::connect(b, SIGNAL(clicked()), this, SLOT(checkMatch()));
        }
    }
    defineWords();
}

void Layout::checkMatch(){

    Button *b = qobject_cast<Button*>(sender());
    QString currentWord = b->word;
    b->setText(currentWord);
    b->setEnabled(false);

    if(this->clickCount == 0){
        this->clickCount += 1;
        this->prevClicked = this->indexOf(b);
    } else {
        this->clickCount = 0;
        disableCarts();

        QEventLoop loop;
            QTimer::singleShot(500, &loop, &QEventLoop::quit);
             loop.exec();

        Button* prevButton = qobject_cast<Button*>(this->itemAt(prevClicked)->widget());
        QString prevWord = prevButton->word;

        if(prevWord == currentWord){
            scr->counter += 1;
            scr->label->setText("Score: " + QString::number(scr->counter));
            b->setText("");
            prevButton->setText("");
            b->setEnabled(false);
            prevButton->setEnabled(false);
        } else {
            b->setText("?");
            prevButton->setText("?");
            prevButton->setEnabled(true);
            b->setEnabled(true);
        }
        enableCarts();
    }

    if(scr->counter == 15){
        this->timer->stop();
        QMessageBox *mb = new QMessageBox();
        mb->setText("You Won!");
        mb->setStandardButtons(QMessageBox::Cancel);
        mb->exec();
    }
}

void Layout::disableCarts(){
    for(int i = 0; i < 30; i++){
        Button* x = qobject_cast<Button*>(this->itemAt(i)->widget());
        x->setEnabled(false);
    }
}

void Layout::enableCarts(){
    for(int i = 0; i < 30; i++){
            Button* z = qobject_cast<Button*>(this->itemAt(i)->widget());
            if(z->text()!=""){
            z->setEnabled(true);
        }
    }
}

void Layout::newGame(){

    this->clickCount = 0;
    this->prevClicked = -1; //never clicked a button

    scr->counter =0;
    scr->label->setText("Score: " + QString::number(0));

    timer->start();
    tmr->counter = 0;

    for (int i = 0; i < this->count(); ++i) {
        Button *widget = qobject_cast<Button*>(this->itemAt(i)->widget());
        widget->setEnabled(true);
        widget->setText("?");
        widget->empty = true;
    }
    defineWords();
}

void Layout::defineWords(){

    for(int i=0; i < 15; ++i){

        QString name="";
        if(i==0){
            name="fish";
        }else if(i==1){
            name="bird";
        }else if(i==2){
            name="cow";
        }else if(i==5){
            name="rabbit";
        }else if(i==3){
            name="bee";
        }else if(i==4){
            name="butterfly";
        }else if(i==6){
            name="dog";
        }else if(i==7){
            name="cat";
        }else if(i==8){
            name="horse";
        }else if(i==9){
            name="chicken";
        }else if(i==10){
            name="monkey";
        }else if(i==11){
            name="donkey";
        }else if(i==12){
            name="sheep";
        }else if(i==13){
            name="pigeon";
        }else if(i==14){
            name="tiger";
        }

        qsrand(QTime::currentTime().msec());
        int z;
        Button *widget;

        do {
            z=qrand()%30;
            widget = qobject_cast<Button*>(this->itemAt(z)->widget());
        } while(widget->empty == false);

        widget->empty = false;
        widget->word = name;


        qsrand(QTime::currentTime().msec());
        int y;
        Button *widget2;

        do {
            y=qrand()%30;
            widget2 = qobject_cast<Button*>(this->itemAt(y)->widget());
        } while(widget2->empty==false);

        widget2->empty=false;
        widget2->word=name;
    }
}
