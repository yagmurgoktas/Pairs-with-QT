#include "Score.h"

Score::Score() : QObject()
{
    this->counter = 0;
    this->label = new QLabel("Score: 0");
}
