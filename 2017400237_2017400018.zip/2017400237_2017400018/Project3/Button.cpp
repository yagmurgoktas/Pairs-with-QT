#include "Button.h"

Button::Button(const QString& word, const QString& text, QWidget* parent) : QPushButton(text, parent)
{
    this->word = word;
    setFlat(true);
    setAutoFillBackground(true);
    update();
    this->empty=true;
}
