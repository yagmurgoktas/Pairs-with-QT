#ifndef LAYOUT_H
#define LAYOUT_H

#include <QTimer>
#include <QGridLayout>
#include <QMessageBox>
#include "Button.h"
#include "Score.h"
#include "Timer.h"
#include <QTime>
#include <QEventLoop>

class Layout : public QGridLayout
{
    Q_OBJECT

public:
    int clickCount;
    int prevClicked; //prev clicked index
    QTimer* timer;
    Score* scr;
    Timer* tmr;

    Layout(QTimer* timer, Score* scr , Timer* tmr);

public slots:
    void newGame();
    void checkMatch();
    void disableCarts();
    void defineWords();
    void enableCarts();
};

#endif // LAYOUT_H
