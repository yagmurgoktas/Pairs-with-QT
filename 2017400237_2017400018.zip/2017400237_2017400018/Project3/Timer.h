#ifndef TIMER_H
#define TIMER_H

#include <QTimer>
#include <QLabel>
#include <QMessageBox>

class Timer : public QObject
{

    Q_OBJECT

public:
    Timer();
    QTimer *tmr;
    QLabel *label;
    int counter;

signals:
    void endOfTime();

public slots:

    void timerSlot();
    void newTimer();
};

#endif // TIMER_H
