#ifndef SCORE_H
#define SCORE_H

#include <QLabel>

class Score : public QObject
{
   Q_OBJECT

public:
    Score();
    int counter;
    QLabel *label;
};

#endif // SCORE_H

