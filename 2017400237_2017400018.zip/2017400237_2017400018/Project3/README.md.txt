Our project is created with
Qt Creator 4.12.3
Based on Qt 5.14.2 (MSVC 2017, 32 bit)